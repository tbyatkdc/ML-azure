## Required Resource Providers

Microsoft.Insights

Microsoft.ContainerInstance

Microsoft.ContainerRegistry

Microsoft.KeyVault

Microsoft.AlertsManagement

Microsoft.OperationalInsights

Microsoft.MachineLearningServices
